import pygame
import time

pygame.init()
pygame.mixer.init()

win = pygame.display.set_mode((700, 500))
pygame.display.set_caption("Naruto vs Sasuke")


walkRight = [pygame.image.load('pics\\NR2.png'), pygame.image.load('pics\\NR3.png'), pygame.image.load('pics\\NR1.png')]
walkLeft = [pygame.image.load('pics\\NL2.png'), pygame.image.load('pics\\NL3.png'), pygame.image.load('pics\\NL1.png')]
walkRightS = [pygame.image.load('pics\\SR2.png'), pygame.image.load('pics\\SR3.png'), pygame.image.load('pics\\SR1.png')]
walkLeftS = [pygame.image.load('pics\\SL2.png'), pygame.image.load('pics\\SL3.png'), pygame.image.load('pics\\SL1.png')]
bg = pygame.image.load('pics\\bg.png')
Nh = pygame.image.load('pics\\Nh.png')
Sh = pygame.image.load('pics\\Sh.png')
welcome_image = pygame.image.load('wel.png')  
start_button_image = pygame.image.load('LOAD.png')
start_button_image = pygame.transform.scale(start_button_image, (200, 50))  
start_button_image.set_alpha(250)  

hitSound = pygame.mixer.Sound("pics\\hit.wav")
pygame.mixer.music.load("naruto_theme.mp3")  
pygame.mixer.music.set_volume(0.2)  
pygame.mixer.music.play(-1) 

Clock = pygame.time.Clock()


button_color = (255, 0, 0)
button_hover_color = (200, 0, 0)
button_rect = pygame.Rect(275, 200, 150, 100)
button_text_color = (255, 255, 255)


game_started = False

class player():
    def __init__(self, x, y, width, height, images_left, images_right):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.speed = 10
        self.isjump = False
        self.jumpheight = 10
        self.left = False
        self.right = False
        self.walkCount = 0
        self.standing = True
        self.hitbox = (self.x + 10, self.y + 5, 80, 80)
        self.health = 200
        self.images_left = images_left
        self.images_right = images_right

    def draw(self, win):
        if self.health > 0:
            if self.walkCount + 1 >= 6:
                self.walkCount = 0
            if not self.standing:
                if self.left:
                    win.blit(self.images_left[self.walkCount // 2], (self.x, self.y))
                    self.walkCount += 1
                elif self.right:
                    win.blit(self.images_right[self.walkCount // 2], (self.x, self.y))
                    self.walkCount += 1
            else:
                if self.right:
                    win.blit(self.images_right[0], (self.x, self.y))
                else:
                    win.blit(self.images_left[0], (self.x, self.y))
            self.hitbox = (self.x + 10, self.y + 5, 80, 80)
        else:
            
            text = font.render('Player Defeated', True, (255, 255, 255))
            win.blit(text, (180, 200))

    def hit(self):
        if self.health > 0:
            self.health -= 10
        else:
            print("Player has 0 health")

class weapons():
    def __init__(self, x, y, width, height, facing):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.facing = facing
        self.vel = 8 * facing
        self.hitbox = (self.x, self.y, 40, 40)

    def draw(self, win):
        win.blit(pygame.image.load('pics\\shur.png'), (self.x, self.y))
        self.hitbox = (self.x, self.y, 40, 40)

naruto = player(30, 400, 100, 100, walkLeft, walkRight)
sasuke = player(600, 400, 100, 100, walkLeftS, walkRightS)

shurikens_naruto = []
shurikens_sasuke = []

throwSpeedNaruto = 0
throwSpeedSasuke = 0

font = pygame.font.SysFont('comicsans', 60, True)


start_time = time.time()
total_time = 50

def redrawGameWindow():
    win.blit(bg, (0, 0))

    
    pygame.draw.rect(win, (255, 0, 0), (80, 40, 200, 25))  
    pygame.draw.rect(win, (0, 255, 0), (80, 40, naruto.health, 25))  
    pygame.draw.rect(win, (255, 0, 0), (400, 40, 200, 25))  
    pygame.draw.rect(win, (0, 255, 0), (400, 40, sasuke.health, 25))  

    
    current_time = time.time()
    elapsed_time = int(current_time - start_time)
    remaining_time = max(0, total_time - elapsed_time)
    timer_text = font.render(f"  {remaining_time}", True, (255, 255, 255))
    win.blit(timer_text, (250, 40))

    
    naruto.draw(win)
    sasuke.draw(win)
    win.blit(Nh, (10, 10))
    win.blit(Sh, (600, 10))

    
    for shuriken in shurikens_naruto:
        shuriken.draw(win)
    for shuriken in shurikens_sasuke:
        shuriken.draw(win)

    pygame.display.update()

def draw_start_screen():
    win.blit(welcome_image, (0, 0))  
    
    
    mouse_pos = pygame.mouse.get_pos()
    if button_rect.collidepoint(mouse_pos):
        win.blit(start_button_image, (button_rect.x, button_rect.y))
    else:
        win.blit(start_button_image, (button_rect.x, button_rect.y))
    
    pygame.display.update()

run = True
while run:
    Clock.tick(25)

    
    if not game_started:
        draw_start_screen()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
            if event.type == pygame.MOUSEBUTTONDOWN:
                if button_rect.collidepoint(pygame.mouse.get_pos()):
                    game_started = True
                    start_time = time.time()  
        continue
    

	
    
    if throwSpeedNaruto > 0:
        throwSpeedNaruto += 1
    if throwSpeedNaruto > 3:
        throwSpeedNaruto = 0

    if throwSpeedSasuke > 0:
        throwSpeedSasuke += 1
    if throwSpeedSasuke > 3:
        throwSpeedSasuke = 0

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False

    
    for shuriken in shurikens_naruto:
        if sasuke.hitbox[1] < shuriken.hitbox[1] < sasuke.hitbox[1] + sasuke.hitbox[3] and \
                sasuke.hitbox[0] < shuriken.hitbox[0] < sasuke.hitbox[0] + sasuke.hitbox[2]:
            sasuke.hit()
            hitSound.play()
            shurikens_naruto.remove(shuriken)

        if 0 < shuriken.x < 700:
            shuriken.x += shuriken.vel
        else:
            shurikens_naruto.remove(shuriken)

    
    for shuriken in shurikens_sasuke:
        if naruto.hitbox[1] < shuriken.hitbox[1] < naruto.hitbox[1] + naruto.hitbox[3] and \
                naruto.hitbox[0] < shuriken.hitbox[0] < naruto.hitbox[0] + naruto.hitbox[2]:
            naruto.hit()
            hitSound.play()
            shurikens_sasuke.remove(shuriken)

        if 0 < shuriken.x < 700:
            shuriken.x += shuriken.vel
        else:
            shurikens_sasuke.remove(shuriken)

    
    keys = pygame.key.get_pressed()

    
    if keys[pygame.K_LEFT] and naruto.x > naruto.speed:
        naruto.x -= naruto.speed
        naruto.left = True
        naruto.right = False
        naruto.standing = False
    elif keys[pygame.K_RIGHT] and naruto.x < 700 - naruto.width - naruto.speed:
        naruto.x += naruto.speed
        naruto.left = False
        naruto.right = True
        naruto.standing = False
    else:
        naruto.standing = True
        naruto.walkCount = 0

    if not naruto.isjump:
        if keys[pygame.K_UP]:
            naruto.isjump = True
            naruto.left = False
            naruto.right = False
            naruto.walkCount = 0
    else:
        if naruto.jumpheight >= -10:
            neg = 1
            if naruto.jumpheight < 0:
                neg = -1
            naruto.y -= (naruto.jumpheight ** 2) * 0.5 * neg
            naruto.jumpheight -= 1
        else:
            naruto.isjump = False
            naruto.jumpheight = 10

    if keys[pygame.K_KP_ENTER] and throwSpeedNaruto == 0:
        facing = -1 if naruto.left else 1
        if len(shurikens_naruto) < 5:
            shurikens_naruto.append(weapons(round(naruto.x + 60), round(naruto.y + 30), 40, 40, facing))
        throwSpeedNaruto = 1

    
    if keys[pygame.K_a] and sasuke.x > sasuke.speed:
        sasuke.x -= sasuke.speed
        sasuke.left = True
        sasuke.right = False
        sasuke.standing = False
    elif keys[pygame.K_d] and sasuke.x < 700 - sasuke.width - sasuke.speed:
        sasuke.x += sasuke.speed
        sasuke.left = False
        sasuke.right = True
        sasuke.standing = False
    else:
        sasuke.standing = True
        sasuke.walkCount = 0

    if not sasuke.isjump:
        if keys[pygame.K_w]:
            sasuke.isjump = True
            sasuke.left = False
            sasuke.right = False
            sasuke.walkCount = 0
    else:
        if sasuke.jumpheight >= -10:
            neg = 1
            if sasuke.jumpheight < 0:
                neg = -1
            sasuke.y -= (sasuke.jumpheight ** 2) * 0.5 * neg
            sasuke.jumpheight -= 1
        else:
            sasuke.isjump = False
            sasuke.jumpheight = 10

    if keys[pygame.K_f] and throwSpeedSasuke == 0:
        facing = -1 if sasuke.left else 1
        if len(shurikens_sasuke) < 5:
            shurikens_sasuke.append(weapons(round(sasuke.x + 60), round(sasuke.y + 30), 40, 40, facing))
        throwSpeedSasuke = 1

    
    current_time = time.time()
    elapsed_time = int(current_time - start_time)
    remaining_time = max(0, total_time - elapsed_time)

    if remaining_time == 0 or naruto.health <= 0 or sasuke.health <= 0:
        run = False

    redrawGameWindow()


win.fill((0, 0, 0))
if naruto.health <= 0:
    result_text = font.render('Naruto lose', True, (255, 0, 0))
elif sasuke.health <= 0:
    result_text = font.render('Sasuke lose', True, (255, 0, 0))
else:
    result_text = font.render('    Draw', True, (255, 0, 0))
win.blit(result_text, (180, 200))
pygame.display.update()
pygame.time.wait(300)  

pygame.quit()
